# Scientific-Computing-Code-
NRF Scientific Computing Intern: at the cross roads of software engineers and science 
This is a console application, coded in C++ programming language.
journal translator is a programme that reads D-space xml schema and translate it to Crossreff xml journal schema
To be able to use this programme, you need a collection folder containing all issue collections with Dspace dublin xml placed 
with respect to their collection number.
All prompting masseges are simple to understand.
please ensure that you create a folder named 'crossreff_files' this is where you will find your results(product crossref.xml file)
avarage time it takes a program to yeald results is 2.5 seconds.
